import React from "react";
import Container3 from "../container3/Container3";

const Container2 = ({ data }) => {
  return (
    <>
      <h2>Container 2</h2>
      {data.map(({ id, value, onchange }, i) => {
        return (
          <Container3
            key={i}
            id={id}
            value={value}
            onchange={onchange}
          ></Container3>
        );
      })}
    </>
  );
};

export default Container2;
