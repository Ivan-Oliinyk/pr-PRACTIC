import React from "react";

const Container3 = ({ id, value, onchange }) => {
  return (
    <div>
      <p>container 3</p>
      <label htmlFor={id}>
        <input id={id} type={value} onChange={() => onchange}></input>
      </label>
    </div>
  );
};

export default Container3;
