import "./App.css";
import Page from "./components/page/Page";

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <div className="Gop">
          <Page></Page>
        </div>
      </header>
    </div>
  );
}

export default App;
