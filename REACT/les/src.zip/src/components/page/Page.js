import React from "react";
import Container1 from "../../conteiner1/Container1";

const Page = () => {
  return (
    <div>
      <Container1></Container1>
    </div>
  );
};

export default Page;
