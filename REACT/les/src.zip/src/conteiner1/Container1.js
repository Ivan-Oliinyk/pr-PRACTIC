import React from "react";
import Container2 from "../container2/Container2";

const data = [
  { key: 1, value: "text", onchange: "text1" },
  { key: 2, value: "text", onchange: "text2" },
  { key: 3, value: "text", onchange: "text3" },
  { key: 4, value: "text", onchange: "text4" },
];

const Container1 = () => {
  return (
    <div>
      <h1>Contaier1</h1>
      <Container2 data={data}></Container2>
    </div>
  );
};

export default Container1;
